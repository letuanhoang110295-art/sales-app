class Product {
  String id;
  String code;
  String name;
  double priceRetail;
  double priceWholesale;
  int stock;
  Product({required this.id, required this.code, required this.name, required this.priceRetail, required this.priceWholesale, required this.stock});
  Map<String, dynamic> toMap() => {
    'id': id,
    'code': code,
    'name': name,
    'price_retail': priceRetail,
    'price_wholesale': priceWholesale,
    'stock': stock
  };
  static Product fromMap(Map<String, dynamic> m) => Product(
    id: m['id'],
    code: m['code'] ?? '',
    name: m['name'] ?? '',
    priceRetail: (m['price_retail'] ?? 0.0) + 0.0,
    priceWholesale: (m['price_wholesale'] ?? 0.0) + 0.0,
    stock: (m['stock'] ?? 0) as int
  );
}
