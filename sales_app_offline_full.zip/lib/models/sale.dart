class Sale {
  String id;
  String productId;
  String productName;
  int qty;
  double unitPrice;
  double total;
  String date;
  Sale({required this.id, required this.productId, required this.productName, required this.qty, required this.unitPrice, required this.total, required this.date});
  Map<String, dynamic> toMap() => {
    'id': id,
    'productId': productId,
    'productName': productName,
    'qty': qty,
    'unitPrice': unitPrice,
    'total': total,
    'date': date
  };
  static Sale fromMap(Map<String, dynamic> m) => Sale(
    id: m['id'],
    productId: m['productId'],
    productName: m['productName'],
    qty: m['qty'],
    unitPrice: (m['unitPrice'] ?? 0.0) + 0.0,
    total: (m['total'] ?? 0.0) + 0.0,
    date: m['date']
  );
}
