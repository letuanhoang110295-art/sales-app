import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../utils/repo.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  final Repo _repo = Repo();
  DateTimeRange? _range;
  List<dynamic> _sales = [];

  void _pickRange() async {
    final now = DateTime.now();
    final picked = await showDateRangePicker(context: context, firstDate: DateTime(now.year-5), lastDate: DateTime(now.year+1));
    if (picked != null) {
      setState(()=>_range = picked);
      final from = picked.start.toIso8601String();
      final to = picked.end.add(const Duration(days:1)).toIso8601String();
      final s = await _repo.getSales(from: from, to: to);
      setState(()=>_sales = s);
    }
  }

  double get total => _sales.fold(0.0, (a,b)=>a+(b.total as double));

  Future<void> _exportPdf() async {
    final pdf = pw.Document();
    final df = DateFormat('yyyy-MM-dd HH:mm');
    pdf.addPage(pw.MultiPage(build: (ctx) => [
      pw.Header(level:0, child: pw.Text('Invoice / Report')),
      pw.Text('Range: ${_range==null? 'All time' : '${_range!.start.toLocal().toString().split(' ')[0]} -> ${_range!.end.toLocal().toString().split(' ')[0]}'}'),
      pw.SizedBox(height:10),
      pw.Table.fromTextArray(context: ctx, data: <List<String>>[<String>['Date','Product','Qty','Unit','Total']] + _sales.map((s) => [DateTime.parse(s.date).toLocal().toString().split('.')[0], s.productName, s.qty.toString(), s.unitPrice.toStringAsFixed(0), s.total.toStringAsFixed(0)]).toList()),
      pw.Divider(),
      pw.Align(alignment: pw.Alignment.centerRight, child: pw.Text('TOTAL: ${total.toStringAsFixed(0)}'))
    ]));
    // Save to file
    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/report_${DateTime.now().millisecondsSinceEpoch}.pdf');
    await file.writeAsBytes(await pdf.save());
    // Offer share/print
    await Printing.sharePdf(bytes: await pdf.save(), filename: 'report.pdf');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reports / Invoice')),
      body: Padding(padding: const EdgeInsets.all(12.0), child: Column(children: [
        ElevatedButton(onPressed: _pickRange, child: const Text('Pick date range')),
        const SizedBox(height:8),
        ElevatedButton(onPressed: _exportPdf, child: const Text('Export PDF / Share')),
        const SizedBox(height:12),
        Expanded(child: _sales.isEmpty? const Center(child: Text('No data')) : ListView.builder(itemCount: _sales.length, itemBuilder: (c,i){
          final s = _sales[i];
          return ListTile(title: Text(s.productName), subtitle: Text('${s.qty} x ${s.unitPrice.toStringAsFixed(0)}'), trailing: Text(s.total.toStringAsFixed(0)));
        }))
      ])),
    );
  }
}
