import 'package:flutter/material.dart';
import '../utils/repo.dart';
import '../models/product.dart';
import '../models/sale.dart';
import 'package:uuid/uuid.dart';
import 'package:intl/intl.dart';

class SalesScreen extends StatefulWidget {
  const SalesScreen({super.key});

  @override
  State<SalesScreen> createState() => _SalesScreenState();
}

class _SalesScreenState extends State<SalesScreen> {
  final Repo _repo = Repo();
  List<Product> _products = [];
  List<Sale> _sales = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() async {
    final p = await _repo.getProducts();
    final s = await _repo.getSales();
    setState(()=>{ _products = p; _sales = s });
  }

  void _sell(Product prod) {
    int qty = 1;
    showDialog(context: context, builder: (ctx){
      return AlertDialog(
        title: Text('Sell ${prod.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('Stock: ${prod.stock}'),
          TextField(decoration: const InputDecoration(labelText: 'Quantity'), keyboardType: TextInputType.number, onChanged: (v)=>qty = int.tryParse(v) ?? 1),
        ]),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(onPressed: () async {
            if (qty <= 0) return;
            final unit = prod.priceRetail;
            final total = unit * qty;
            final sale = Sale(id: const Uuid().v4(), productId: prod.id, productName: prod.name, qty: qty, unitPrice: unit, total: total, date: DateTime.now().toIso8601String());
            await _repo.insertSale(sale);
            await _repo.reduceStock(prod.id, qty);
            Navigator.pop(ctx);
            _load();
          }, child: const Text('Confirm')),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sales')),
      body: Padding(padding: const EdgeInsets.all(8.0), child: Column(children: [
        Card(child: ListTile(title: const Text('Products'), subtitle: const Text('Tap an item to sell'))),
        const SizedBox(height:8),
        Expanded(child: Row(children: [
          Expanded(child: _productList()),
          const SizedBox(width:8),
          Expanded(child: _salesList()),
        ]))
      ])),
    );
  }

  Widget _productList() => Card(child: Column(children: [
    const ListTile(title: Text('Products')),
    const Divider(height:1),
    Expanded(child: _products.isEmpty? const Center(child: Text('No products')) : ListView.builder(itemCount: _products.length, itemBuilder: (c,i){
      final p = _products[i];
      return ListTile(title: Text(p.name), subtitle: Text('Price: ${p.priceRetail.toStringAsFixed(0)} • Stock: ${p.stock}'), onTap: ()=>_sell(p));
    }))
  ]));

  Widget _salesList() => Card(child: Column(children: [
    ListTile(title: const Text('Sales')),
    const Divider(height:1),
    Expanded(child: _sales.isEmpty? const Center(child: Text('No sales yet')) : ListView.builder(itemCount: _sales.length, itemBuilder: (c,i){
      final s = _sales[i];
      return ListTile(title: Text('${s.productName} x${s.qty}'), subtitle: Text(DateFormat('yyyy-MM-dd HH:mm').format(DateTime.parse(s.date))), trailing: Text(s.total.toStringAsFixed(0)));
    }))
  ]));
}
