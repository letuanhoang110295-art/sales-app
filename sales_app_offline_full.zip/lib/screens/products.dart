import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/product.dart';
import '../utils/repo.dart';

class ProductsScreen extends StatefulWidget {
  const ProductsScreen({super.key});

  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  final Repo _repo = Repo();
  List<Product> _items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _load() async {
    final items = await _repo.getProducts();
    setState(()=>_items = items);
  }

  void _showForm({Product? p}) {
    final id = p?.id ?? const Uuid().v4();
    String code = p?.code ?? '';
    String name = p?.name ?? '';
    String pr = p?.priceRetail.toString() ?? '0';
    String pw = p?.priceWholesale.toString() ?? '0';
    String stock = p?.stock.toString() ?? '0';
    showDialog(context: context, builder: (ctx){
      return AlertDialog(
        title: Text(p==null? 'Add product' : 'Edit product'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(decoration: const InputDecoration(labelText: 'Code'), onChanged: (v)=>code=v, controller: TextEditingController(text: code)),
          TextField(decoration: const InputDecoration(labelText: 'Name'), onChanged: (v)=>name=v, controller: TextEditingController(text: name)),
          TextField(decoration: const InputDecoration(labelText: 'Price (retail)'), keyboardType: TextInputType.number, onChanged: (v)=>pr=v, controller: TextEditingController(text: pr)),
          TextField(decoration: const InputDecoration(labelText: 'Price (wholesale)'), keyboardType: TextInputType.number, onChanged: (v)=>pw=v, controller: TextEditingController(text: pw)),
          TextField(decoration: const InputDecoration(labelText: 'Stock'), keyboardType: TextInputType.number, onChanged: (v)=>stock=v, controller: TextEditingController(text: stock)),
        ])),
        actions: [
          TextButton(onPressed: ()=>Navigator.pop(ctx), child: const Text('Cancel')),
          ElevatedButton(onPressed: () async {
            final prod = Product(id: id, code: code, name: name, priceRetail: double.tryParse(pr) ?? 0.0, priceWholesale: double.tryParse(pw) ?? 0.0, stock: int.tryParse(stock) ?? 0);
            await _repo.insertProduct(prod);
            Navigator.pop(ctx);
            _load();
          }, child: const Text('Save')),
        ],
      );
    });
  }

  void _delete(String id) async {
    await _repo.deleteProduct(id);
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Products'), actions: [IconButton(onPressed: ()=>_showForm(), icon: const Icon(Icons.add))]),
      body: Padding(padding: const EdgeInsets.all(8.0), child: _items.isEmpty? const Center(child: Text('No products yet')) : ListView.builder(itemCount: _items.length, itemBuilder: (c,i){
        final p = _items[i];
        return ListTile(
          title: Text(p.name),
          subtitle: Text('Code: ${p.code} • Retail: ${p.priceRetail.toStringAsFixed(0)} • Stock: ${p.stock}'),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            IconButton(icon: const Icon(Icons.edit), onPressed: ()=>_showForm(p: p)),
            IconButton(icon: const Icon(Icons.delete), onPressed: ()=>_delete(p.id)),
          ]),
        );
      })),
    );
  }
}
