import 'package:uuid/uuid.dart';
import 'package:sqflite/sqflite.dart';
import '../utils/db_helper.dart';
import '../models/product.dart';
import '../models/sale.dart';

class Repo {
  final DBHelper _helper = DBHelper();
  final Uuid _uuid = const Uuid();

  Future<void> insertProduct(Product p) async {
    final db = await _helper.db;
    await db.insert('products', p.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Product>> getProducts() async {
    final db = await _helper.db;
    final rows = await db.query('products', orderBy: 'name');
    return rows.map((r) => Product.fromMap(r)).toList();
  }

  Future<void> deleteProduct(String id) async {
    final db = await _helper.db;
    await db.delete('products', where: 'id=?', whereArgs: [id]);
  }

  Future<void> updateProduct(Product p) async {
    final db = await _helper.db;
    await db.update('products', p.toMap(), where: 'id=?', whereArgs: [p.id]);
  }

  Future<void> insertSale(Sale s) async {
    final db = await _helper.db;
    await db.insert('sales', s.toMap(), conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Sale>> getSales({String? from, String? to}) async {
    final db = await _helper.db;
    String where = '';
    List<dynamic> args = [];
    if (from != null && to != null) {
      where = 'date BETWEEN ? AND ?';
      args = [from, to];
    }
    final rows = await db.query('sales', where: where==''?null:where, whereArgs: args, orderBy: 'date DESC');
    return rows.map((r) => Sale.fromMap(r)).toList();
  }

  Future<void> reduceStock(String productId, int qty) async {
    final db = await _helper.db;
    final rows = await db.query('products', where: 'id=?', whereArgs: [productId]);
    if (rows.isNotEmpty) {
      final p = Product.fromMap(rows.first);
      final newStock = p.stock - qty;
      await db.update('products', {'stock': newStock}, where: 'id=?', whereArgs: [productId]);
    }
  }
}
