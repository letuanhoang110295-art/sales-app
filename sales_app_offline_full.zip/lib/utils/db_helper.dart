import 'dart:async';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DBHelper {
  static final DBHelper _instance = DBHelper._internal();
  factory DBHelper() => _instance;
  DBHelper._internal();

  static Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final databasesPath = await getDatabasesPath();
    final path = join(databasesPath, 'sales.db');
    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  FutureOr<void> _onCreate(Database db, int version) async {
    await db.execute('''CREATE TABLE products (
      id TEXT PRIMARY KEY,
      code TEXT,
      name TEXT,
      price_retail REAL,
      price_wholesale REAL,
      stock INTEGER
    )''');
    await db.execute('''CREATE TABLE sales (
      id TEXT PRIMARY KEY,
      productId TEXT,
      productName TEXT,
      qty INTEGER,
      unitPrice REAL,
      total REAL,
      date TEXT
    )''');
  }
}
